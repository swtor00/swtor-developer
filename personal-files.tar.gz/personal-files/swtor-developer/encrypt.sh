#!/usr/bin/bash

tar cvzf personal-files.tar.gz ../personal-files
gpg -c personal-files.tar.gz








