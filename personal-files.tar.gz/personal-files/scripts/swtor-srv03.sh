ssh -42C swtor00@217.61.16.98



